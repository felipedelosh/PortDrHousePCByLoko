$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
$classes = Join-Path $PSScriptRoot 'build\classes'
New-Item -ItemType Directory -Force -Path $classes | Out-Null
$files = @(Get-ChildItem -Path '.\src\main\java' -Recurse -Filter '*.java' | ForEach-Object { $_.FullName })
& javac --release 21 -encoding UTF-8 -d $classes @files
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
& java -cp "$classes;$PSScriptRoot\src\main\resources" Main
exit $LASTEXITCODE
